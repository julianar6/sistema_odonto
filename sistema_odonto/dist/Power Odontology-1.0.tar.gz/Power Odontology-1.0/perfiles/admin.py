from django.contrib import admin

from perfiles.models import Avatar


admin.site.register(Avatar)
