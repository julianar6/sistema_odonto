from setuptools import setup, find_packages

# Llamar a la funcion setup
setup(
    name="Power Odontology",
    version="1.0",
    description="Herramientas creacion de usarios",
    author="Julian Arboleda",
    packages=find_packages()
)