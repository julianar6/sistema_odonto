from django.apps import AppConfig


class ControlOdontoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'control_odonto'
